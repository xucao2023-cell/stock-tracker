All financial amounts USD billion, shares billion. EUR per ordinary common share.
Run: python MU-20261119-corrected-model.py --inputs MU-20261119-corrected-old-inputs.json --fx MU-20261119-corrected-fx.json --output reproduced.json --market-price-usd 700.39
Core numeric fields reproduce exactly; selection/quote metadata is publication-only.
