#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
腾讯控股 (00700.HK) 估值模型 —— DCF(FCFF) + 倍数 + 情景 + 资本开支失败分析
仅依赖标准库，Python 3.8+ 可直接运行：  python tencent_valuation.py

金额单位：人民币百万元 (RMB mn)；每股结果另给出 HKD。
数据来源：2026 年中报（截至 2026-06-30）+ 2025 年年报（截至 2025-12-31），
          市场价取 2026-08-13 收盘 441.0 港元。
免责声明：仅供学习/分析，非投资建议。
"""

from __future__ import annotations

# ================= 市场与口径 =================
PRICE_HKD = 441.0            # 2026-08-13 收盘
SHARES    = 9070.0           # 百万股（9,120M 已发行 - 50M H1 回购置销）
FX        = 6.7888 / 7.80    # RMB per HKD ≈ 0.8704
MKT_CAP_RMB = PRICE_HKD * SHARES * FX

INV_LISTED  = 487200.0       # 上市投资公允价值 (2026-06-30)
INV_UNLIST  = 387900.0       # 非上市投资账面值
NET_CASH    = 58191.0
MINORITY    = 86660.0
TAX         = 0.14           # non-IFRS 有效税率
SBC_PCT     = 0.033          # 股权激励 ≈ 3.3% 收入（经济成本，非现金但稀释）
ROIC        = 0.25           # 终值再投资率 = g/ROIC

INV_BASE = INV_LISTED + INV_UNLIST * 0.50   # 非上市投资打 5 折


# ================= 预测与 DCF =================
def forecast(rev2026: float, g: list[float], margin: list[float],
             da_pct: list[float], capex: list[float], dwc: list[float]) -> dict:
    """10 年显式预测 (2026..2035)。NOPAT 为经济口径（扣 SBC）。"""
    rev, op, nopat, da, fcff = [], [], [], [], []
    r = rev2026
    rev.append(r)
    for gi in g:
        r *= (1.0 + gi)
        rev.append(r)
    for i in range(10):
        opi = rev[i] * margin[i]
        op.append(opi)
        nopat_i = (opi - SBC_PCT * rev[i]) * (1.0 - TAX)
        nopat.append(nopat_i)
        dai = rev[i] * da_pct[i]
        da.append(dai)
        fcff.append(nopat_i + dai - capex[i] - dwc[i])
    return {"rev": rev, "op": op, "nopat": nopat, "da": da, "fcff": fcff}


def run_dcf(fc: dict, wacc: float, gterm: float, roic: float, inv: float) -> dict:
    """显式期 2026-2034 折现 + 归一化终值（再投资率 = g/ROIC）。"""
    pv = sum(fc["fcff"][i] / (1.0 + wacc) ** (i + 1) for i in range(9))
    nopat10 = fc["nopat"][9]
    fcf10 = nopat10 * (1.0 - gterm / roic)          # 归一化终年 FCFF
    tv = fcf10 * (1.0 + gterm) / (wacc - gterm)
    core_ev = pv + (fcf10 + tv) / (1.0 + wacc) ** 10
    eq = core_ev + inv + NET_CASH - MINORITY
    return {"pv": pv, "fcf10": fcf10, "tv": tv, "core_ev": core_ev,
            "eq": eq, "hkd": eq / SHARES / FX}


# ================= 各情景参数 =================
DWC = [40000.0] + [0.0] * 9

BASE = forecast(
    827200.0,
    [0.09, 0.09, 0.08, 0.08, 0.07, 0.07, 0.06, 0.05, 0.05],
    [0.374, 0.375, 0.375, 0.375, 0.380, 0.380, 0.380, 0.380, 0.380, 0.380],
    [0.097, 0.105, 0.110, 0.110, 0.108, 0.105, 0.102, 0.100, 0.100, 0.100],
    [205000, 195000, 185000, 175000, 165000, 160000, 160000, 160000, 165000, 170000],
    DWC,
)

BEAR = forecast(
    827200.0,
    [0.05, 0.05, 0.05, 0.05, 0.04, 0.04, 0.04, 0.03, 0.03],
    [0.360, 0.355, 0.350, 0.350, 0.350, 0.350, 0.350, 0.350, 0.350, 0.350],
    [0.097, 0.105, 0.110, 0.110, 0.108, 0.105, 0.102, 0.100, 0.100, 0.100],
    [210000, 200000, 190000, 180000, 170000, 165000, 165000, 165000, 170000, 175000],
    DWC,
)
INV_BEAR = INV_LISTED * 0.90 + INV_UNLIST * 0.40

BULL = forecast(
    827200.0,
    [0.11, 0.11, 0.10, 0.09, 0.09, 0.08, 0.07, 0.06, 0.06],
    [0.380, 0.385, 0.390, 0.390, 0.395, 0.395, 0.395, 0.395, 0.395, 0.395],
    [0.097, 0.105, 0.110, 0.110, 0.108, 0.105, 0.102, 0.100, 0.100, 0.100],
    [205000, 195000, 185000, 175000, 165000, 160000, 160000, 160000, 165000, 170000],
    DWC,
)
INV_BULL = INV_LISTED + INV_UNLIST * 0.60

# 资本开支“失败”：AI 不产生增量收入/盈利，增速塌到 3%，利润率被折旧拖累
FAILURE = forecast(
    827200.0,
    [0.03] * 9,
    [0.360, 0.345, 0.335, 0.335, 0.335, 0.335, 0.335, 0.335, 0.335, 0.335],
    [0.097, 0.105, 0.110, 0.108, 0.105, 0.102, 0.100, 0.098, 0.096, 0.095],
    [205000, 110000, 110000, 115000, 120000, 125000, 130000, 135000, 140000, 145000],
    DWC,
)

# 极端：零增长 + 利润率 33% + 高折现率
EXTREME = forecast(
    827200.0,
    [0.0] * 9,
    [0.360, 0.340, 0.330, 0.330, 0.330, 0.330, 0.330, 0.330, 0.330, 0.330],
    [0.097, 0.105, 0.110, 0.108, 0.105, 0.102, 0.100, 0.098, 0.096, 0.095],
    [205000] + [110000] * 9,
    DWC,
)


# ================= 输出辅助 =================
def _n(x: float, d: int = 0) -> str:
    return f"{x:,.{d}f}"


def main() -> None:
    print("=" * 78)
    print("腾讯控股 (00700.HK) 估值模型")
    print(f"股价 {PRICE_HKD} HKD | 市值 {_n(MKT_CAP_RMB)} RMB = "
          f"{_n(PRICE_HKD * SHARES)} HKD | FX {FX:.4f}")
    print("=" * 78)

    # ---- 基准逐年 ----
    print("\n=== 基准情形：逐年预测 (RMB mn) ===")
    print(f"{'Year':<6}{'Revenue':>12}{'OpProfit':>12}{'NOPAT':>12}"
          f"{'DnA':>10}{'CapEx':>11}{'FCFF':>11}")
    for i in range(10):
        print(f"{2026 + i:<6}{BASE['rev'][i]:>12,.0f}{BASE['op'][i]:>12,.0f}"
              f"{BASE['nopat'][i]:>12,.0f}{BASE['da'][i]:>10,.0f}"
              f"{[205000,195000,185000,175000,165000,160000,160000,160000,165000,170000][i]:>11,.0f}"
              f"{BASE['fcff'][i]:>11,.0f}")

    # ---- 基准 DCF ----
    print("\n=== 基准情形 DCF (WACC=8.0%, g=3.5%, 终值ROIC=25%) ===")
    d = run_dcf(BASE, 0.08, 0.035, ROIC, INV_BASE)
    print(f"显式期FCFF现值 = {_n(d['pv'])}")
    print(f"归一化FCF2035 = {_n(d['fcf10'])} ; 终值 = {_n(d['tv'])}")
    print(f"核心业务EV = {_n(d['core_ev'])}")
    print(f"股权价值 = {_n(d['eq'])} RMB ; 每股 = {_n(d['eq']/SHARES,1)} RMB "
          f"= {_n(d['hkd'],1)} HKD")
    print(f"相对 441 HKD 空间 = {(d['hkd']/PRICE_HKD - 1)*100:+.1f}%")

    # ---- 敏感性 ----
    print("\n=== 敏感性：每股HKD (行=WACC, 列=永续g; ROIC=25%) ===")
    gs = [0.025, 0.030, 0.035, 0.040, 0.045]
    print("WACC      " + "".join(f"{f'g={g:.1%}':>11}" for g in gs))
    for w in [0.070, 0.075, 0.080, 0.085, 0.090, 0.095]:
        row = f"WACC={w:.1%} "
        for g in gs:
            row += f"{run_dcf(BASE, w, g, ROIC, INV_BASE)['hkd']:>11,.1f}"
        print(row)

    # ---- 反推 ----
    print("\n=== 反推：当前股价隐含什么 ===")
    target = MKT_CAP_RMB
    lo, hi = 0.04, 0.16
    for _ in range(60):
        mid = (lo + hi) / 2
        if run_dcf(BASE, mid, 0.035, ROIC, INV_BASE)["eq"] > target:
            lo = mid
        else:
            hi = mid
    print(f"g=3.5% 时隐含WACC = {(lo+hi)/2:.2%}")
    # 注意：WACC 8% 下即使 g=0 价值仍高于市值 → 不存在非负 g 能匹配现价
    v_g0 = run_dcf(BASE, 0.08, 0.0, ROIC, INV_BASE)["hkd"]
    print(f"WACC=8% 且永续g=0 时价值 = {v_g0:,.0f} HKD (仍高于 441，"
          f"故无正 g 能匹配现价)")

    # ---- 情景 ----
    print("\n=== 情景测试 (每股HKD) ===")
    print(f"熊市 = {run_dcf(BEAR, 0.09, 0.030, 0.20, INV_BEAR)['hkd']:,.1f} "
          f"(低增长/高capex, WACC9%, g3%, 投资组合上市9折·非上市4折)")
    print(f"牛市 = {run_dcf(BULL, 0.075, 0.040, 0.30, INV_BULL)['hkd']:,.1f} "
          f"(高增长/扩张margin, WACC7.5%, g4%, 投资组合非上市6折)")
    print(f"CAPEX失败 = {run_dcf(FAILURE, 0.09, 0.030, 0.20, INV_BASE)['hkd']:,.1f} "
          f"(AI零增量收入, WACC9%, g3%)")
    print(f"CAPEX失败(WACC8.5%) = "
          f"{run_dcf(FAILURE, 0.085, 0.030, 0.20, INV_BASE)['hkd']:,.1f}")
    print(f"极端(0增长) = {run_dcf(EXTREME, 0.095, 0.025, 0.18, INV_BASE)['hkd']:,.1f} "
          f"(WACC9.5%, g2.5%)")

    # ---- 直接减值冲击 ----
    print("\n=== 直接减值冲击（非现金，单独计）===")
    print("设需减值的AI累计资本开支 = X，减值50%（回本一半）:")
    for x in [50000, 100000, 150000, 200000]:
        loss = x * 0.50
        hkd = loss / SHARES / FX
        print(f"  X={x:>7,.0f}  减值={loss:>7,.0f}  -> 每股 -{loss/SHARES:,.1f} RMB "
              f"= -{hkd:,.1f} HKD  ({hkd/PRICE_HKD:.1%} of 441)")

    # ---- 合成 ----
    print("\n=== 合成：失败情景价值 再减 直接减值(假设减值1500亿→冲减750亿) ===")
    eq_adj = run_dcf(FAILURE, 0.09, 0.030, 0.20, INV_BASE)["eq"] - 150000 * 0.50
    print(f"失败(WACC9%) 减 750亿减值 -> 每股 {eq_adj/SHARES/FX:,.1f} HKD")
    print(f"对比：现价 441 HKD | 基准 842 HKD | 熊市 479 HKD")

    # ---- 倍数交叉验证 ----
    print("\n=== 倍数估值交叉验证 ===")
    ni_fwd = 259626 * 1.10            # FY2026E non-IFRS 归母净利
    eps_fwd = ni_fwd / SHARES
    print(f"FY2026E non-IFRS归母净利 = {_n(ni_fwd)} ; EPS = {eps_fwd:,.1f} RMB")
    print(f"当前市场 non-IFRS 前瞻PE = {MKT_CAP_RMB/ni_fwd:,.1f}x")
    for pe in [15, 18, 20]:
        print(f"  纯PE {pe}x -> {pe*eps_fwd/FX:,.1f} HKD")

    ebitda26 = 309000 + 80000
    ev_core_mkt = MKT_CAP_RMB - (INV_LISTED + INV_UNLIST) - NET_CASH
    print(f"FY2026E EBITDA = {_n(ebitda26)} ; 当前核心EV/EBITDA = "
          f"{ev_core_mkt/ebitda26:,.1f}x")
    for m in [9, 10, 12]:
        eq_f = m * ebitda26 + INV_BASE + NET_CASH - MINORITY
        print(f"  EV/EBITDA {m}x -> {eq_f/SHARES/FX:,.1f} HKD")

    core_earn = 265700 + 4000
    print(f"FY2026E 核心盈利(SOTP口径) = {_n(core_earn)}")
    for pe in [15, 18, 20]:
        eq_f = pe * core_earn + INV_BASE + NET_CASH - MINORITY
        print(f"  SOTP 核心{pe}x + 投资组合 -> {eq_f/SHARES/FX:,.1f} HKD")

    print("\n免责声明：本模型为分析练习，非投资建议。")


if __name__ == "__main__":
    main()
