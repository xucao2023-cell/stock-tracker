# Siltronic 2026Q3 valuation reproduction

Python 3 + scipy. From the extracted directory, run `python scripts/q3_review_20261104.py`. Output is written to extracted/q3_review_20261104.json. All monetary inputs are EUR million; share count million; output EUR/share. Source labels distinguish actual accounts, analyst forecasts and unverified self-built proxies.
