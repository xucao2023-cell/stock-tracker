Amounts CNY100m, shares100m, prices CNY per ordinary A-share. No FX or ADS.
Reproduce the quoted snapshot without network: pip install numpy scipy xlsxwriter
Run python 600900_长江电力_changjiangdianli/scripts/revaluation_20261120.py
Compare extracted/revaluation_20261120/model_results.json. The Nov20 inputs and prior model JSON are bundled. The source fetch script is optional and updates the vintage if rerun.
